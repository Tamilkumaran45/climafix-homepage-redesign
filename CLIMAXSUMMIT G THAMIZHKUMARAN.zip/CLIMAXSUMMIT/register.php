<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "climaxdb";  // change to your DB name

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]));
}


// Read POST data
$data = json_decode(file_get_contents("php://input"), true);

$name = $conn->real_escape_string($data["name"]);
$dob = $conn->real_escape_string($data["dob"]);
$profession = $conn->real_escape_string($data["profession"]);
$email = $conn->real_escape_string($data["email"]);
$whatsapp = $conn->real_escape_string($data["whatsapp"]);

$sql = "INSERT INTO registrations (name, dob, profession, email, whatsapp)
        VALUES ('$name', '$dob', '$profession', '$email', '$whatsapp')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success", "message" => "Registration successful"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed: " . $conn->error]);
}

$conn->close();
?>