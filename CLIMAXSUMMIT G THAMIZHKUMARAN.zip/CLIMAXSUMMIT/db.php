<?php
$host = "localhost";    // Usually localhost for XAMPP
$username = "root";     // Default XAMPP username
$password = "";         // Default XAMPP password is empty
$database = "climafix_db";      // Your database name

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Database connected successfully.";

// Close connection (optional here)
$conn->close();
?>